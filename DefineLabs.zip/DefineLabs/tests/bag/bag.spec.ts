import { test, expect } from '@playwright/test';

test.describe('Shopping Bag Tests', () => {
    test.beforeEach(async ({ page }) => {
        // Set longer timeout for navigation
        test.setTimeout(60000);
    });

    test.afterEach(async ({ page }, testInfo) => {
        // Take screenshot on failure
        if (testInfo.status !== testInfo.expectedStatus) {
            await page.screenshot({ path: `bag-test-failed-${Date.now()}.png` });
        }
    });

    test('shopping bag functionality test', async ({ page }) => {
        // Navigate to homepage and verify
        await page.goto('https://www.bhaane.com/');
        await expect(page).toHaveURL('https://www.bhaane.com/');

        // Close initial popup if present
        const closePopup = page.locator('#mdiv div').first();
        if (await closePopup.isVisible()) {
            await closePopup.click();
        }

        // Click on shopping bag icon
        const bagIcon = page.getByRole('img').nth(2);
        await expect(bagIcon).toBeVisible();
        await bagIcon.click();

        // Verify bag modal
        const bagModal = page.locator('#modal-bag');
        await expect(bagModal).toBeVisible();
        await bagModal.click();

        // Wait for and handle new product page
        const page1Promise = page.waitForEvent('popup');
        const productLink = page.locator('div:nth-child(4) > a');
        await expect(productLink).toBeVisible();
        await productLink.click();
        
        const productPage = await page1Promise;
        
        // Add item to bag
        const addToBagButton = productPage.getByRole('button', { name: 'add to bag' });
        await expect(addToBagButton).toBeVisible();
        await expect(addToBagButton).toBeEnabled();
        await addToBagButton.click();

        // Verify bag modal on product page
        const bagModalButton = productPage.locator('#modal-bag').getByRole('button');
        await expect(bagModalButton).toBeVisible();
        await bagModalButton.click();

        // Navigate to cart
        const goToCartLink = productPage.getByRole('link', { name: 'go to cart' });
        await expect(goToCartLink).toBeVisible();
        await goToCartLink.click();

        // Click checkout button
        const checkoutButton = productPage.getByRole('button', { name: 'checkout' });
        await expect(checkoutButton).toBeVisible();
        await expect(checkoutButton).toBeEnabled();
        await checkoutButton.click();

        // Verify cart page URL
        await productPage.goto('https://www.bhaane.com/cart');
        await expect(productPage).toHaveURL('https://www.bhaane.com/cart');

        // Test promotion code section
        const promoCodeHeading = productPage.getByRole('heading', { name: 'use promotion code >' });
        await expect(promoCodeHeading).toBeVisible();
        await promoCodeHeading.click();

        // Enter and verify promotion code
        const promoCodeInput = productPage.locator('input[name="coupon_code"]');
        await expect(promoCodeInput).toBeVisible();
        await promoCodeInput.click();
        await promoCodeInput.fill('dsfd');

        // Apply promotion code
        const applyButton = productPage.getByRole('button', { name: 'Apply' });
        await expect(applyButton).toBeEnabled();
        await applyButton.click();

        // Verify invalid coupon message
        const invalidCouponText = productPage.locator('#cart').getByText('Invalid coupon');
        await expect(invalidCouponText).toBeVisible();
        await expect(invalidCouponText).toHaveText('Invalid coupon');
        await invalidCouponText.click();

        // Additional verifications
        await expect(page).toHaveTitle(/.*Bhaane.*/); // Verify page title contains "Bhaane"
        await expect(productPage.locator('#cart')).toBeVisible(); // Verify cart section is visible
    });
});