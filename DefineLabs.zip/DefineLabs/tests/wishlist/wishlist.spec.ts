import { test, expect } from '@playwright/test';

test.describe('Wishlist Tests', () => {
    test.beforeEach(async ({ page }) => {
        test.setTimeout(60000);
    });

    test.afterEach(async ({ page }, testInfo) => {
        if (testInfo.status !== testInfo.expectedStatus) {
            await page.screenshot({ path: `wishlist-test-failed-${Date.now()}.png` });
        }
    });

    test('wishlist functionality and login test', async ({ page }) => {
        // Navigate to homepage and verify
        await page.goto('https://www.bhaane.com/');
        await expect(page).toHaveURL('https://www.bhaane.com/');
        await expect(page).toHaveTitle(/.*Bhaane.*/);

        // Close initial popup if present
        const closePopup = page.locator('#mdiv');
        if (await closePopup.isVisible()) {
            await closePopup.click();
        }

        // Wait for and handle new product page
        const page1Promise = page.waitForEvent('popup');
        const productLink = page.locator('div:nth-child(4) > a');
        await expect(productLink).toBeVisible();
        await productLink.click();
        
        const productPage = await page1Promise;
        await productPage.waitForLoadState('networkidle');

        // Click wishlist button to trigger login
        const wishlistButton = productPage.getByRole('button', { name: 'wishlist' });
        await expect(wishlistButton).toBeVisible();
        await wishlistButton.click();

        // Login form interaction
        const loginForm = productPage.locator('#modal-login');
        await expect(loginForm).toBeVisible();

        // Fill email
        const emailInput = loginForm.locator('input[name="email"]');
        await expect(emailInput).toBeVisible();
        await emailInput.click();
        await emailInput.fill('paragpatil.new@gmail.com');
        await expect(emailInput).toHaveValue('paragpatil.new@gmail.com');

        // Fill password
        const passwordInput = loginForm.locator('input[name="password"]');
        await expect(passwordInput).toBeVisible();
        await passwordInput.click();
        await passwordInput.fill('Parag@123');
        await expect(passwordInput).toHaveValue('Parag@123');

        // Submit login
        const submitButton = productPage.getByRole('button', { name: 'submit' });
        await expect(submitButton).toBeEnabled();
        await submitButton.click();

        // Verify successful login and add to wishlist
        await productPage.waitForLoadState('networkidle');
        await wishlistButton.click();
        
        // Navigate to bottoms category
        const bottomsLink = productPage.getByRole('link', { name: 'bottoms' });
        await expect(bottomsLink).toBeVisible();
        await bottomsLink.click();
        await productPage.waitForLoadState('networkidle');

        // Select specific product
        const lilithPantsLink = productPage.locator('#products div')
            .filter({ hasText: 'lilith pants + ₹5,900 ₹' })
            .getByRole('link');
        await expect(lilithPantsLink).toBeVisible();
        await lilithPantsLink.click();
        await productPage.waitForLoadState('networkidle');

        // Add second item to wishlist
        const secondWishlistButton = productPage.getByRole('button', { name: 'wishlist' });
        await expect(secondWishlistButton).toBeVisible();
        await secondWishlistButton.click();

    });
});
