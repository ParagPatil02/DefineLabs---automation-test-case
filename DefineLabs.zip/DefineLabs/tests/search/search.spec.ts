import { test, expect } from '@playwright/test';

test('search functionality and navigation test', async ({ page }) => {
    // Go to homepage and verify it loaded
    await page.goto('https://www.bhaane.com/');
    await expect(page).toHaveURL('https://www.bhaane.com/');

    // Email signup section
    const emailSignup = page.getByText('email').nth(4);
    await expect(emailSignup).toBeVisible();
    await emailSignup.click();

    // Fill email form
    const emailInput = page.locator('form').filter({ hasText: 'email sign up' }).getByRole('textbox');
    await expect(emailInput).toBeVisible();
    await emailInput.fill('parag@gmail.com');

    // Click signup and verify
    const signupButton = page.getByRole('button', { name: 'sign up' });
    await expect(signupButton).toBeEnabled();
    await signupButton.click();

    // Close popup if present
    const closeButton = page.locator('#mdiv div').nth(1);
    if (await closeButton.isVisible()) {
        await closeButton.click();
    }

    // Search functionality test - "naidu" search
    const searchIcon = page.getByRole('img').nth(3);
    await expect(searchIcon).toBeVisible();
    await searchIcon.click();

    const searchBox = page.getByRole('textbox', { name: 'search' });
    await expect(searchBox).toBeVisible();
    await searchBox.click();
    await searchBox.fill('naidu');
    await searchBox.press('Enter');

    // Verify search results
    const naiduPantsLink = page.getByText('Naidu Pants +');
    await expect(naiduPantsLink).toBeVisible();
    await naiduPantsLink.click();

    // Click on specific product and verify navigation
    const stripeNaiduLink = page.getByRole('link', { name: 'Bhaane Royce Stripes Naidu' });
    await expect(stripeNaiduLink).toBeVisible();
    await stripeNaiduLink.click();

    // Currency selector interaction
    const currencyList = page.getByRole('list').filter({ hasText: '₹ $ € £ account' });
    await expect(currencyList).toBeVisible();
    const currencyItem = currencyList.getByRole('listitem').nth(3);
    await currencyItem.click();

    // Test search with "test" keyword
    await searchBox.click();
    await searchBox.fill('test');
    await searchBox.press('Enter');
    
    // Verify currency/account section visibility
    const accountSection = page.getByText('₹ $ € £ account');
    await expect(accountSection).toBeVisible();
    await accountSection.click();

    // Header search icon interaction
    const headerSearchIcon = page.locator('#top-header').getByRole('img').nth(3);
    await expect(headerSearchIcon).toBeVisible();
    await headerSearchIcon.click();

    // Test search with invalid query
    await searchBox.click();
    await searchBox.fill('hsdhhjhf');
    await searchBox.press('Enter');

    // Verify search results message
    const searchResultText = page.getByText('Showing search results for "');
    await expect(searchResultText).toBeVisible();
    await searchResultText.click();
});