import { test, expect } from '@playwright/test';

test('test', async ({ page }) => {
    // Navigate to homepage
    await page.goto('https://www.bhaane.com/');
    
    // Close initial popup
    await page.locator('#mdiv').click();
    
    // Start signup process
    await page.locator('#top-header').getByText('account').click();
    await page.getByText('sign up >').click();
    
    // Fill signup form - Part 1 (Personal Details)
    await page.locator('input[name="first_name"]').click();
    await page.locator('input[name="first_name"]').fill('parag');
    await page.locator('input[name="last_name"]').click();
    await page.locator('input[name="last_name"]').fill('patil');
    await page.locator('#modal-register input[name="email"]').click();
    await page.locator('#modal-register input[name="email"]').fill('parag@gmail.com');
    await page.getByRole('button', { name: 'submit' }).click();
    
    // Fill signup form - Part 2 (Contact & Security)
    await page.locator('input[name="mobile"]').click();
    await page.locator('input[name="mobile"]').fill('8787787877');
    await page.locator('#modal-register input[name="password"]').click();
    await page.locator('#modal-register input[name="password"]').fill('test@123');
    await page.getByRole('button', { name: 'submit' }).click();
    
 
    

});